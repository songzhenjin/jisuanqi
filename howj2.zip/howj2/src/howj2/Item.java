package howj2;

public class Item {
	String name;
	int price;
	
	public static void main(String[] args) {
		Item caoxie = new Item();
		caoxie.name = "��Ь";
		caoxie.price = 300;
	}
}
