package howj2;

public class bianliang {
	public static void main(String[] args) {
		double a = 3.14;
		double b = 2.76985;
		short c = 365;
		byte d = 12;
		char e = 'π';
		boolean f = false;
		String g = "计算器";
	}
}
