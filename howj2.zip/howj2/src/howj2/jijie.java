package howj2;
import java.util.Scanner;
public class jijie {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("�������·ݣ�");
		int a = s.nextInt();
		
		switch(a) {
		case 1: case 2: case 3:
			System.out.println("����");
			break;
		case 4: case 5: case 6:
			System.out.println("����");
			break;
		case 7: case 8: case 9:
			System.out.println("�ļ�");
		case 10: case 11: case 12:
			System.out.println("�＾");
		default:
			System.out.println("FUCK U!");
		}
	}
}
