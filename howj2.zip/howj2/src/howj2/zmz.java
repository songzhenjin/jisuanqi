package howj2;

public class zmz {
	public static void main(String[] args) {
		int a = 100;
		float b = 30.1F;
		System.out.println("a\r\n"+"b");
	}
}
