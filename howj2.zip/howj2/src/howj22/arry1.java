package howj22;

public class arry1 {
	public static void main(String[] args) {
		int a[] = new int[5];
		
		for(int i=0;i<a.length;i++) {
			a[i] = (int)(Math.random()*100);
			System.out.println(a[i]);
		}
		//���鷴ת
		for(int i=4;i>=0;i--) {
			System.out.println(a[i]);
		}
	}
}
