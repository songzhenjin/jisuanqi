package howj22;
//������ҵ
public class ArryHK {
	public static void main(String[] args) {
		int a[] = new int[5];
		for(int i=0;i<a.length;i++) {
			a[i] = (int)(Math.random()*100);
			System.out.println("����ǰ�����飺"+a[i]);
		}
		System.out.println();
		for(int i=0;i<a.length-1;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[j]<a[i]) {
					int temp = a[j];
					a[j] = a[i];
					a[i] = temp;
				}
			}
		}
		for(int i=0;i<a.length;i++) {
			System.out.println("���������飺"+a[i]);
		}
	}
}
