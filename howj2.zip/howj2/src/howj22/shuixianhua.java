package howj22;

public class shuixianhua {
	public static void main(String[] args) {
		//ˮ�ɻ���
		int i = 100;
		while(i<1000) {
			int a = i / 100;
			int b = (i-a*100)/10;
			int c = i-(a*100+b*10);
			
			int sum;
			sum = a*a*a+b*b*b+c*c*c;
			if(i==sum) {// = �Ǹ�ֵ  == �����
				System.out.println(i);
			}
			i++;
		}
	}
}
