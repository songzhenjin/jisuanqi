package learn;
//��ά���� ��ҵ
public class ErWeiArry {
	public static void main(String[] args) {
		int a[][] = new int[5][5];
		int max = a[0][0];
		int target_i = 0;
		int target_j = 0;
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a.length;j++) {
				a[i][j] = (int)(Math.random()*100);
				System.out.println(a[i][j]+" ");
				
				if(a[i][j]>max) {
					max = a[i][j];
					target_i = i;
					target_j = j;
				}
				
			}
		}
		System.out.println("���ֵ�ǣ�"+max);
		System.out.println("�������ǣ�"+target_i+target_j);
	}
}
