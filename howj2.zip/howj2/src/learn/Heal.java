package learn;

public class Heal extends Hero{
	public void Support() {
		System.out.println("����");
	}
	public void Support(Hero hs) {
		System.out.println(name+"��"+hs.name+"����");
	}
	public void Support(Hero hs, int hp) {
		System.out.println(name+"��"+hs.name+"������"+hp);
	}
	
	public static void main(String[] args) {
		Heal naima = new Heal();
		naima.name = "����";
		
		Hero hs = new Hero();
		hs.name = "����";
		naima.Support(hs);
		naima.Support(hs,200);

	}
}
class Hero{
	String name;
}